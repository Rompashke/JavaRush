package com.javarush.task.pro.task10.task1020;

public class Monitor {
}
