package com.javarush.task.pro.task10.task1017;

public class SouthAmerica {
    private final int area;

    public SouthAmerica(int area) {
        this.area = area;
    }
}
