package com.javarush.task.pro.task12.task1218;

import java.io.File;
import java.util.*;

/* 
Shine bright like a diamond
*/

public class Solution {

    public static void main(String[] args) {
        ArrayList<String> stringArrayList = new ArrayList<>();
        Stack<String> stack = new Stack<>();
        Map<String, ArrayList<String>> map = new HashMap<>();
        var exceptionsList = new ArrayList<Exception>();
        var filesStack = new Stack<File>();
    }
}
/*
Требования:
1.	Замени тип элементов объекта на оператор diamond где это возможно.
2.	Левую часть выражений изменять нельзя.
 */
