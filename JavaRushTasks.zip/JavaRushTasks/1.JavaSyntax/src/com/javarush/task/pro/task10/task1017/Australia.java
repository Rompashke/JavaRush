package com.javarush.task.pro.task10.task1017;

public class Australia {
    private final int area;

    public Australia(int area) {
        this.area = area;
    }
}
