package com.javarush.task.pro.task07.task0715;

public class Human extends Entity {
//    public void move(){
//        System.out.println("Я передвигаюсь.");
//    }

//    public void eat(){
//        System.out.println("Я ем.");
//    }

    public void speak(){
        System.out.println("Я умею общаться.");
    }
}
