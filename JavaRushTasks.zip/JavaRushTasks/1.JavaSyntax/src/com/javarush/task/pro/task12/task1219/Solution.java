package com.javarush.task.pro.task12.task1219;

import java.util.ArrayList;

/* 
Двойные фигурные скобки
*/

public class Solution {

    public static void main(String[] args) {
        var  strings = new ArrayList<String>()
        {{
                add("Так");
                add("тоже");
                add("можно");
                add("делать");
                add("!");
        }};
    }
}
/*
Требования:
1.	Список strings должен заполняться пятью элементами в двойных фигурных скобках.
 */
