package com.javarush.task.pro.task06.task0606;

/* 
Универсальный солдат
*/

public class Solution {

    public static void main(String[] args) {

    }

    public static void universalMethod(int a){

    }

    public static void universalMethod(String a) {}
    public static void universalMethod(double a) {}
    public static void universalMethod(byte a) {}
    public static void universalMethod(long a) {}
    public static void universalMethod(char a) {}
    public static void universalMethod(String a, String b) {}
    public static void universalMethod(String a, int b) {}
    public static void universalMethod(String a, short b) {}
    public static void universalMethod(short a) {}

}
