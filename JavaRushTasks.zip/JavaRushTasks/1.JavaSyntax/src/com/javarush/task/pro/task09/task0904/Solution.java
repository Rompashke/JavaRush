package com.javarush.task.pro.task09.task0904;

/* 
Символьные литералы
*/

public class Solution {
    public static char first = '\u004A';
    public static char second = 'a';
    public static char third = '\u0076';
    public static char fourth = 'a';

    public static void main(String[] args) {
        System.out.print(first);
        System.out.print(second);
        System.out.print(third);
        System.out.print(fourth);
    }
}
/*
1. Переменной first нужно присвоить значение '\u004A'.
2. Переменной second нужно присвоить значение 'a'.
3. Переменной third нужно присвоить значение '\u0076'.
4. Переменной fourth нужно присвоить значение 'a'.
 */
