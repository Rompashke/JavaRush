package com.javarush.task.pro.task07.task0714;

/* 
Наследование переменных
*/

public class Car extends Vehicle {
//    double maxSpeed;
    int wheelCount;
    double weight;
}
