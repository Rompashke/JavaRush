package com.javarush.task.pro.task11.task1101;

/* 
Солнечная система — наш дом
*/

public class SolarSystem {

    public static long age = 4_568_200_000L;

    public static int planetsCount = 8;

    public static int starsCount = 1;

    public static String starName = "Солнце";

    public static int galacticCenterDistance = 27170;


}
