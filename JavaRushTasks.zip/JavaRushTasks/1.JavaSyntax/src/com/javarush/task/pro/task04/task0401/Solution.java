package com.javarush.task.pro.task04.task0401;

/* 
Я никогда не буду работать за копейки
*/

public class Solution {
    public static void main(String[] args) {
        String quote = "Я никогда не буду работать за копейки. Амиго";
        int i = 0;
        while (i < 100)
        {
            System.out.println(quote);
            i++;
        }
    }
}