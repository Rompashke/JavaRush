package com.javarush.task.pro.task07.task0715;

/* 
Наследование методов
*/

public class Entity {
    public void move(){
        System.out.println("Я передвигаюсь.");
    }

    public void eat(){
        System.out.println("Я ем.");
    }
}
