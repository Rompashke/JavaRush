package com.javarush.task.pro.task12.task1216;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

/* 
Вперед в будущее
*/

public class Solution {
    private int number = 54;
    private String string = "string";

    public static void main(String[] args) {
        var integer = 22;
        var string = "string";
        var array = new int[5];
        var strings = new ArrayList<String>();
        var bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        var maxValue = Integer.valueOf(Integer.MAX_VALUE);
    }
}
/*
Требования:
1.	Замени типы переменных на var, где это возможно.
2.	Не изменяй правую часть выражений.
 */
