package com.javarush.task.pro.task10.task1017;

public class Africa {
    private final int area;

    public Africa(int area) {
        this.area = area;
    }
}
