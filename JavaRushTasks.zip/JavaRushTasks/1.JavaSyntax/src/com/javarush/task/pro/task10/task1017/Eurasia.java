package com.javarush.task.pro.task10.task1017;

public class Eurasia {
    private final int area;

    public Eurasia(int area) {
        this.area = area;
    }
}
