package com.javarush.task.pro.task07.task0713;

/* 
Простое наследование
*/

public class Terran {
}
