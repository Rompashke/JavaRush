package com.javarush.task.pro.task10.task1017;

public class NorthAmerica {
    private final int area;

    public NorthAmerica(int area) {
        this.area = area;
    }
}
