package com.javarush.task.pro.task12.task1217;

/* 
Назад в прошлое
*/

public class Solution {
    private int[] intArray = new int[4];

    public int[] getIntArray() {
        return intArray;
    }

    public void setIntArray(int[] intArray) {
        this.intArray = intArray;
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        String string = new String("Hello");
        StringBuilder stringBuilder = new StringBuilder();
    }
}
/*
Требования:
1.	Замени типы переменных c var на конкретный тип объекта.
2.	Почини геттер и сеттер для поля intArray.
 */
