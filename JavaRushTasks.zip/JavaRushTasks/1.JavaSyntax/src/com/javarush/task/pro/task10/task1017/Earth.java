package com.javarush.task.pro.task10.task1017;

/* 
Создание материков
*/

public class Earth {
    public static void main(String[] args) {
        Africa africa = new Africa(35);
        Antarctica antarctica = new Antarctica(32);
        Australia australia = new Australia(25);
        Eurasia eurasia = new Eurasia(99);
        NorthAmerica northAmerica = new NorthAmerica(57);
        SouthAmerica southAmerica = new SouthAmerica(37);
    }
}
