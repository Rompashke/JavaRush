package com.javarush.task.pro.task11.task1106;

/* 
Одинаковые машины
*/

public class Car {
    private String modelName;
    private int speed;

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
/*
Требования:
1.	Поле modelName класса Car должно быть не статическим.
2.	Должны быть исправлены геттер и сеттер для поля modelName.
 */
