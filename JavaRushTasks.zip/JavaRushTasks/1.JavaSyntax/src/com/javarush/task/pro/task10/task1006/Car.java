package com.javarush.task.pro.task10.task1006;

public class Car {

    public Car(String type) {
        System.out.println("Привет. Я " + type);
    }
}
