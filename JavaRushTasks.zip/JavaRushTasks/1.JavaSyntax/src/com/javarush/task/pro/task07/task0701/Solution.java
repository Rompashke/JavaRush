package com.javarush.task.pro.task07.task0701;

/* 
Все возможные типы
*/

public class Solution {
    byte a;
    short b;
    int c;
    long d;
    float e;
    double f;
    boolean g;
    char h;
}
