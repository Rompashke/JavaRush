package com.javarush.task.pro.task07.task0712;

/* 
Первые объекты
*/

import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        String a = new String("");
        String b = new String("");
        String c = new String("");
        String d = new String("");
        String i = new String("");
        String f = new String("");
        String g = new String("");
        String h = new String("");
        String j = new String("");
        String k = new String("");
        int[] number1 = new int[1];
        int[] number2 = new int[2];
        int[] number3 = new int[3];
        int[] number4 = new int[4];
        int[] number5 = new int[5];
        Scanner console = new Scanner("");
        Scanner console2 = new Scanner("");


    }
}
/*
Используя оператор new в методе main(), создай:
- 10 объектов типа String;
- 5 объектов типа int[] (массивов значений int);
- 2 объекта типа Scanner.


Требования:
1.	В методе main() должно создаваться 10 объектов типа String.
2.	В методе main() должно создаваться 5 объектов типа int[].
3.	В методе main() должно создаваться 2 объекта типа Scanner.
 */
