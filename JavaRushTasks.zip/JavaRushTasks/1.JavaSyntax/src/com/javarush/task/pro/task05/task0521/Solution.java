package com.javarush.task.pro.task05.task0521;

/* 
Выполнение фрагмента кода
*/

public class Solution {

    public static int result = 45967;

    public static void main(String[] args) {
        String loop = "    for (double fahrenheit = -459.67; fahrenheit < 451; fahrenheit += 40) {\n";
        System.out.println(loop);
    }
}

