package com.javarush.task.pro.task10.task1017;

public class Antarctica {
    private final int area;

    public Antarctica(int area) {
        this.area = area;
    }
}
