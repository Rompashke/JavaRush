package com.javarush.task.pro.task07.task0702;

/* 
Максимальное целое
*/

public class Solution {
    byte a = Byte.MAX_VALUE;
    short b = Short.MAX_VALUE;
    int c = Integer.MAX_VALUE;
    long d = Long.MAX_VALUE;
}
