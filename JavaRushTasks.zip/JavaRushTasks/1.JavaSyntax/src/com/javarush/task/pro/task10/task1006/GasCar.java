package com.javarush.task.pro.task10.task1006;

public class GasCar extends Car {

    public GasCar() {
        super("GasCar");
    }
}
