package com.javarush.task.pro.task05.task0501;

/* 
Создаем массивы
*/

public class Solution {
    public static void main(String[] args) {
    int [] intArray = new int[10];
    intArray [0] = 10;
    intArray [1] = 11;
    intArray [2] = 12;
    intArray [3] = 13;
    intArray [4] = 14;
    intArray [5] = 15;
    intArray [6] = 16;
    intArray [7] = 17;
    intArray [8] = 18;
    intArray [9] = 19;
    double[] doubleArray = new double [10];
    }
}
