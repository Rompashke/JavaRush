package com.javarush.task.pro.task09.task0901;

/* 
Целочисленные литералы
*/

public class Solution {
    public byte b = -128;
    public short s = -32768;
    public int i = 1_234_567_890;
    public long l = 2_345_678_900L;
}
