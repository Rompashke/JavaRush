package com.javarush.task.pro.task07.task0703;

/* 
Минимальное целое
*/

public class Solution {
    byte a = Byte.MIN_VALUE;
    short b = Short.MIN_VALUE;
    int c = Integer.MIN_VALUE;
    long d = Long.MIN_VALUE;
}
